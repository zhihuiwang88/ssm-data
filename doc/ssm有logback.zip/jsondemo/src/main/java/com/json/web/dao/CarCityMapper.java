package com.json.web.dao;

import java.util.List;

import com.json.web.entity.CarCity;

public interface CarCityMapper {

	List<CarCity> findAll();

}
