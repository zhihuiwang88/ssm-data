package com.json.web.service.impl;

import java.util.List;

import com.json.web.entity.CarCity;

public interface CarCityService {
	 
	 List<CarCity> find();
}
