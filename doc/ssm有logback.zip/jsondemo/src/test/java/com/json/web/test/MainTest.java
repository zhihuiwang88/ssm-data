package com.json.web.test;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MainTest {

	
	private static  ObjectMapper  objectMapper =new ObjectMapper();
	
	
	
	public static void main(String[] args) {
		try {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
