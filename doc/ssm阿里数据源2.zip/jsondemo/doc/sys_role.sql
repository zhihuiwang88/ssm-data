/*
Navicat MySQL Data Transfer

Source Server         : gongan
Source Server Version : 50627
Source Host           : localhost:3306
Source Database       : jsondata

Target Server Type    : MYSQL
Target Server Version : 50627
File Encoding         : 65001

Date: 2020-03-27 14:59:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `id` int(64) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `note` varchar(32) DEFAULT NULL,
  `created_user` varchar(128) DEFAULT NULL,
  `modified_user` varchar(128) DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `modified_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', '王2', '23', '87', '56', '2020-03-10 18:02:25', '2020-03-04 15:09:16');
INSERT INTO `sys_role` VALUES ('2', '张三', '5', '2', '6', '2020-03-04 00:00:00', '2020-03-17 00:00:00');
INSERT INTO `sys_role` VALUES ('3', '中国', '123', '34', '56', '2020-03-27 00:00:00', '2020-03-27 00:00:00');
INSERT INTO `sys_role` VALUES ('4', '王1', '23', '87', '56', '2020-03-27 00:00:00', '2020-03-27 00:00:00');
INSERT INTO `sys_role` VALUES ('5', '王五', '23', '87', '56', '2020-03-27 00:00:00', '2020-03-27 00:00:00');
INSERT INTO `sys_role` VALUES ('6', '可以', '23', '4', '5', '2020-02-27 14:40:19', '2020-03-24 14:40:22');
INSERT INTO `sys_role` VALUES ('7', '通过', '4', '5', '6', '2020-02-27 14:54:33', '2020-03-17 14:54:36');
