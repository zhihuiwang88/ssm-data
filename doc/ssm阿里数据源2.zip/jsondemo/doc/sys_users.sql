/*
Navicat MySQL Data Transfer

Source Server         : gongan
Source Server Version : 50627
Source Host           : localhost:3306
Source Database       : jsondata

Target Server Type    : MYSQL
Target Server Version : 50627
File Encoding         : 65001

Date: 2020-03-27 08:52:12
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_users
-- ----------------------------
DROP TABLE IF EXISTS `sys_users`;
CREATE TABLE `sys_users` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(64) DEFAULT NULL,
  `pass_word` varchar(32) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of sys_users
-- ----------------------------
INSERT INTO `sys_users` VALUES ('3', '李四6', 'lisi', '123', '2020-03-26 17:28:02', '2020-03-26 17:28:02');
INSERT INTO `sys_users` VALUES ('4', '李四1', 'lisi', '123', '2020-03-26 16:21:29', '2020-03-26 16:21:29');
INSERT INTO `sys_users` VALUES ('5', '李四2', 'lisi', '123', '2020-03-26 16:23:35', '2020-03-26 16:23:35');
INSERT INTO `sys_users` VALUES ('6', '李四3', 'lisi', '123', '2020-03-26 16:24:38', '2020-03-26 16:24:38');
INSERT INTO `sys_users` VALUES ('8', '李四4', 'lisi', '123', '2020-03-26 17:11:50', '2020-03-26 17:11:50');
INSERT INTO `sys_users` VALUES ('9', '李四5', 'lisi', '123', '2020-03-26 17:14:40', '2020-03-26 17:14:40');
