package com.json.web.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.json.web.dao.CarCityMapper;
import com.json.web.entity.CarCity;

@Service
public class CarCityServiceImpl implements CarCityService {

	@Autowired
	private CarCityMapper carCityMapper;
	
	

	public List<CarCity> find() {
		List<CarCity> list = carCityMapper.findAll();
		return list;
	}

}
